See "iOS support" in README.md.
